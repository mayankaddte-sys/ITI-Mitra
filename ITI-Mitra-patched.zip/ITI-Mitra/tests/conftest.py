import os
import re
import tempfile
import types

import numpy as np
import pytest

# Must be set before the backend package is imported.
_tmp = tempfile.mkdtemp(prefix="itimitra_test_")
os.environ.update(
    ADMIN_API_KEY="test-admin-key",
    VECTOR_DB_PATH=os.path.join(_tmp, "db"),
    UPLOAD_DIR=os.path.join(_tmp, "uploads"),
    OPENAI_API_KEY="sk-test",
    CHAT_RATE_LIMIT_PER_MIN="1000",
    MIN_SCORE="0.2",
)

DIM = 512


def fake_embed(texts):
    """Deterministic bag-of-words embedding (handles Hindi tokens too) - no network."""
    out = np.zeros((len(texts), DIM), dtype=np.float32)
    for i, t in enumerate(texts):
        for tok in re.findall(r"\w+", t.lower()):
            out[i, hash(tok) % DIM] += 1.0
    norms = np.linalg.norm(out, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return out / norms


class FakeCompletions:
    def __init__(self):
        self.last_messages = None

    def create(self, **kw):
        self.last_messages = kw["messages"]
        msg = types.SimpleNamespace(content="FAKE ANSWER")
        return types.SimpleNamespace(choices=[types.SimpleNamespace(message=msg)])


@pytest.fixture()
def env(monkeypatch):
    from fastapi.testclient import TestClient

    from backend import app as app_module

    app_module.store.clear()
    from backend import analytics
    analytics.clear()
    monkeypatch.setattr(app_module.store, "embed_texts", fake_embed)
    completions = FakeCompletions()
    fake_client = types.SimpleNamespace(chat=types.SimpleNamespace(completions=completions))
    monkeypatch.setattr(app_module, "get_client", lambda: fake_client)
    return types.SimpleNamespace(client=TestClient(app_module.app), app=app_module, llm=completions)
